%% Computer Vision Challenge

% Groupnumber:
group_number = 0;

% Groupmembers:
% members = {'Max Mustermann', 'Johannes Daten'};
members = {};

% Email-Adress (from Moodle!):
% mail = {'ga99abc@tum.de', 'daten.hannes@tum.de'};
mail = {};

%% Load images


%% Free Viewpoint Rendering
% start execution timer -> tic;


% stop execution timer -> toc;
elapsed_time = Inf;

%% Display Output
% Display Virtual View